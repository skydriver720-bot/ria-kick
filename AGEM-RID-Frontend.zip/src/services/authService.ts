import { demoAccounts } from '../constants/demoAccounts'
import type { AuthUser, SignInRequest } from '../types/auth'

export async function signIn(request: SignInRequest): Promise<AuthUser> {
  if (request.mode === 'sso') {
    throw new Error('SSO sign-in is not configured yet. Please contact your administrator.')
  }

  if (!import.meta.env.DEV) {
    throw new Error('Password sign-in is not configured. Demo accounts are disabled in production.')
  }

  const email = request.email.trim().toLowerCase()
  const account = demoAccounts.find(
    (candidate) => candidate.email === email && candidate.password === request.password,
  )

  if (!account) {
    throw new Error('Invalid email address or password. Use one of the listed demo accounts.')
  }

  return { email: account.email, name: account.name, role: account.role }
}
