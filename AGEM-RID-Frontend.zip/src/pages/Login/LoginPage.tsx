import { useState } from 'react'
import type { FormEvent } from 'react'
import { Alert, Box, Button, Link, TextField, Typography } from '@mui/material'
import AppHeader from '../../components/AppHeader'
// import loginIllustration from '../../assets/login-illustration.png'
import type { LoginPageProps, SignInMode } from '../../types/auth'

export default function LoginPage({ onSignIn, demoAccounts }: LoginPageProps) {
  const [mode, setMode] = useState<SignInMode>('sso')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError(null)

    if (!onSignIn) {
      setError(
        `${mode === 'sso' ? 'SSO' : 'Password'} sign-in is not configured yet. Please contact your administrator.`,
      )
      return
    }

    setIsSubmitting(true)
    try {
      await onSignIn({
        mode,
        email: email.trim(),
        ...(mode === 'password' ? { password } : {}),
      })
    } catch (cause: unknown) {
      setError(
        cause instanceof Error
          ? cause.message || 'Unable to sign in. Please try again.'
          : 'Unable to sign in. Please try again.',
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  function toggleMode() {
    setMode(mode === 'sso' ? 'password' : 'sso')
    setPassword('')
    setError(null)
  }

  return (
    <Box sx={{ minHeight: '100svh', bgcolor: 'background.default' }}>
      <AppHeader />
      <Box
        component="main"
        sx={{
          maxWidth: 1440,
          mx: 'auto',
          px: { xs: 3, sm: '7.35%' },
          pt: { xs: 7, md: 'clamp(100px, 12.2vw, 176px)' },
          pb: 6,
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', md: 'minmax(0, 1fr) minmax(0, 1fr)' },
          columnGap: { md: 8, lg: 12 },
          alignItems: 'start',
        }}
      >
        <Box
          component="section"
          aria-labelledby="login-heading"
          sx={{ width: '100%', maxWidth: 357, mx: { xs: 'auto', md: 0 } }}
        >
          <Typography
            id="login-heading"
            component="h1"
            sx={{ fontSize: 24, fontWeight: 600, lineHeight: 1.3 }}
          >
            {mode === 'sso' ? 'Sign in with SSO' : 'Sign in using Password'}
          </Typography>
          <Typography sx={{ fontSize: 12, mt: 0.1, mb: 2.25 }}>
            Gen AI Driven Data Extraction Tool
          </Typography>

          {demoAccounts && (
            <Alert severity="warning" sx={{ mb: 2, fontSize: 12 }}>
              Demo mode only. Use "Sign In using Password" to try a demo account.
              SSO is not configured.
            </Alert>
          )}

          <Box component="form" onSubmit={handleSubmit} aria-busy={isSubmitting}>
            <Typography
              component="label"
              htmlFor="login-email"
              sx={{ display: 'block', fontSize: 12, color: 'text.secondary', mb: 0.75 }}
            >
              Email address
            </Typography>
            <TextField
              id="login-email"
              name="email"
              type="email"
              autoComplete="username"
              required
              fullWidth
              value={email}
              onChange={(event) => {
                setEmail(event.target.value)
                setError(null)
              }}
              disabled={isSubmitting}
              slotProps={{ htmlInput: { 'aria-label': 'Email address', maxLength: 254 } }}
              sx={{
                '& .MuiOutlinedInput-root': { height: 43, borderRadius: '9px', fontSize: 14 },
                '& .MuiOutlinedInput-input': { height: '100%', boxSizing: 'border-box', py: 1.25 },
                '& .MuiOutlinedInput-notchedOutline': { borderColor: '#d6d6d6' },
              }}
            />
            {mode === 'password' && (
              <Box sx={{ mt: 2 }}>
                <Typography
                  component="label"
                  htmlFor="login-password"
                  sx={{ display: 'block', fontSize: 12, color: 'text.secondary', mb: 0.75 }}
                >
                  Password
                </Typography>
                <TextField
                  id="login-password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  fullWidth
                  value={password}
                  onChange={(event) => {
                    setPassword(event.target.value)
                    setError(null)
                  }}
                  disabled={isSubmitting}
                  slotProps={{ htmlInput: { 'aria-label': 'Password' } }}
                  sx={{
                    '& .MuiOutlinedInput-root': { height: 43, borderRadius: '9px', fontSize: 14 },
                    '& .MuiOutlinedInput-input': { height: '100%', boxSizing: 'border-box', py: 1.25 },
                    '& .MuiOutlinedInput-notchedOutline': { borderColor: '#d6d6d6' },
                  }}
                />
              </Box>
            )}
            {error && (
              <Alert severity="error" sx={{ mt: 2, fontSize: 12 }}>
                {error}
              </Alert>
            )}
            <Button
              type="submit"
              variant="contained"
              loading={isSubmitting}
              sx={{ mt: 2.4, minWidth: 69, height: 31, px: 2.25, fontSize: 12 }}
            >
              Login
            </Button>
          </Box>

          <Box sx={{ mt: 3.5 }}>
            <Typography sx={{ fontSize: 12, color: 'text.secondary' }}>
              {mode === 'sso' ? 'Not using SSO?' : 'Using SSO?'}
            </Typography>
            <Link
              component="button"
              type="button"
              onClick={toggleMode}
              disabled={isSubmitting}
              sx={{
                display: 'block',
                fontSize: 13,
                color: '#008ab8',
                textAlign: 'left',
                '&:focus-visible': { outline: '2px solid #008ab8', outlineOffset: 3 },
                '&:disabled': { opacity: 0.5, cursor: 'default' },
              }}
            >
              {mode === 'sso' ? 'Sign In using Password' : 'Sign In with SSO'}
            </Link>
          </Box>
          {mode === 'password' && demoAccounts && (
            <Box sx={{ mt: 3 }}>
              <Typography component="h2" sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>
                Demo accounts
              </Typography>
              {demoAccounts.map((account) => (
                <Box key={account.email} sx={{ mb: 1 }}>
                  <Typography sx={{ fontSize: 12, fontWeight: 600 }}>{account.role}</Typography>
                  <Typography sx={{ fontSize: 12, overflowWrap: 'anywhere' }}>
                    Email: {account.email}
                  </Typography>
                  <Typography sx={{ fontSize: 12 }}>
                    Password: {account.password}
                  </Typography>
                </Box>
              ))}
              <Typography sx={{ fontSize: 12, color: 'text.secondary' }}>
                Public test credentials only. Do not enter a real password.
              </Typography>
            </Box>
          )}
        </Box>

        <Box
          aria-hidden="true"
          sx={{
            display: 'flex',
            justifyContent: { xs: 'center', md: 'flex-end' },
            mt: { xs: 5, md: 3 },
          }}
        >
          <Box
            component="img"
           // src={loginIllustration}
            alt=""
            width={430}
            height={360}
            sx={{ display: 'block', width: '100%', maxWidth: 430, height: 'auto' }}
          />
        </Box>
      </Box>
    </Box>
  )
}
