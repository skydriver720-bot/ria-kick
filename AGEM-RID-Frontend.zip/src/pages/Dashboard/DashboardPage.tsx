import { Alert, Box, Button, Chip, Stack, Typography } from '@mui/material'
import AppHeader from '../../components/AppHeader'
import { useAuth } from '../../hooks/AuthContext'

export default function DashboardPage() {
  const { user, signOut } = useAuth()

  return (
    <Box sx={{ minHeight: '100svh' }}>
      <AppHeader />
      <Box component="main" sx={{ maxWidth: 1100, mx: 'auto', p: { xs: 3, md: 6 } }}>
        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          spacing={2}
          sx={{
            mb: 3,
            justifyContent: 'space-between',
            alignItems: { xs: 'flex-start', sm: 'center' },
          }}
        >
          <Typography component="h1" variant="h4">
            Dashboard
          </Typography>
          <Button variant="outlined" onClick={signOut}>Sign out</Button>
        </Stack>
        <Alert severity="warning" sx={{ mb: 3 }}>
          Demo mode: this is a local UI demonstration, not secure authentication.
          Refreshing the page signs you out.
        </Alert>
        <Typography component="h2" variant="h6" sx={{ mb: 1 }}>
          Welcome, {user?.name}
        </Typography>
        <Typography sx={{ mb: 2, overflowWrap: 'anywhere' }}>{user?.email}</Typography>
        <Chip label={user?.role} variant="outlined" sx={{ mb: 3 }} />
        <Typography color="text.secondary">
          Your demo password login was successful. Operational dashboard metrics and
          remittance workflows are not connected yet.
        </Typography>
      </Box>
    </Box>
  )
}
