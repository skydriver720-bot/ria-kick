export type SignInMode = 'sso' | 'password'

export type UserRole = 'User' | 'HITL Reviewer' | 'Admin'

export interface AuthUser {
  email: string
  name: string
  role: UserRole
}

export interface DemoAccount extends AuthUser {
  password: string
}

export interface AuthContextValue {
  user: AuthUser | null
  signIn: (request: SignInRequest) => Promise<void>
  signOut: () => void
}

export interface SignInRequest {
  mode: SignInMode
  email: string
  password?: string
}

export interface LoginPageProps {
  onSignIn?: (request: SignInRequest) => Promise<void>
  demoAccounts?: readonly DemoAccount[]
}
