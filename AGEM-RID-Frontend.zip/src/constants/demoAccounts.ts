import type { DemoAccount } from '../types/auth'

// Public demo credentials only; never use these accounts for real authentication.
export const demoAccounts: readonly DemoAccount[] = [
  { email: 'user@example.com', name: 'Demo User', role: 'User', password: 'DemoOnly123!' },
  {
    email: 'reviewer@example.com',
    name: 'Demo Reviewer',
    role: 'HITL Reviewer',
    password: 'DemoOnly123!',
  },
  { email: 'admin@example.com', name: 'Demo Admin', role: 'Admin', password: 'DemoOnly123!' },
]
