import { Box, Typography } from '@mui/material'

export default function AppHeader() {
  return (
    <Box
      component="header"
      sx={{
        height: 60,
        px: { xs: 3, sm: 3 },
        display: 'flex',
        alignItems: 'center',
        bgcolor: 'primary.main',
        color: '#ffffff',
        boxShadow: '0 16px 32px rgba(0, 0, 0, 0.12)',
        position: 'relative',
        zIndex: 1,
      }}
    >
      <Typography
        component="span"
        aria-label="Remittance Interpretation"
        sx={{ fontSize: { xs: 14, sm: 18 }, letterSpacing: 0.3, lineHeight: 1.2 }}
      >
        REMITTANCE
        <Box component="span" sx={{ color: 'secondary.main' }}>
          INTERPRETATION
        </Box>
      </Typography>
    </Box>
  )
}
