import { useCallback, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { AuthContext } from '../hooks/AuthContext'
import { signIn as authenticate } from '../services/authService'
import type { AuthUser, SignInRequest } from '../types/auth'

export default function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)

  const signIn = useCallback(async (request: SignInRequest) => {
    const authenticatedUser = await authenticate(request)
    setUser(authenticatedUser)
  }, [])

  const signOut = useCallback(() => setUser(null), [])
  const value = useMemo(() => ({ user, signIn, signOut }), [user, signIn, signOut])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
