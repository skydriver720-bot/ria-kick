import { createTheme } from '@mui/material/styles'

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: '#131a38' },
    secondary: { main: '#00b9ef' },
    background: { default: '#ffffff' },
    text: { primary: '#373737', secondary: '#666666' },
  },
  typography: {
    fontFamily: '"Segoe UI", Arial, sans-serif',
    button: { textTransform: 'none' },
  },
  components: {
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: {
          borderRadius: 24,
          '&.Mui-focusVisible': {
            outline: '3px solid #00b9ef',
            outlineOffset: 3,
          },
        },
      },
    },
  },
})

export default theme
