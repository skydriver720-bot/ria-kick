import { Navigate, Route, Routes } from 'react-router-dom'
import LoginPage from '../pages/Login/LoginPage'
import DashboardPage from '../pages/Dashboard/DashboardPage'
import { demoAccounts } from '../constants/demoAccounts'
import { useAuth } from '../hooks/AuthContext'
import ProtectedRoute from './ProtectedRoute'

export default function AppRoutes() {
  const { user, signIn } = useAuth()

  return (
    <Routes>
      <Route
        path="/login"
        element={
          user ? <Navigate to="/dashboard" replace /> : (
            <LoginPage
              onSignIn={signIn}
              demoAccounts={import.meta.env.DEV ? demoAccounts : undefined}
            />
          )
        }
      />
      <Route element={<ProtectedRoute />}>
        <Route path="/dashboard" element={<DashboardPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
